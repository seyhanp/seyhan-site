#!/bin/sh

java -cp "./seyhan-pservice-1.0.0.jar:./lib/*" com.seyhanproject.pservice.Service
